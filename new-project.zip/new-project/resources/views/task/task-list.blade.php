@extends('layout.task-layout')

@section('content')
<div class="row">
    <div class="col-sm-offset-2 col-sm-10 mb-5">
    <input type="text" id="task_name" name="task_name" placeholder="Enter task">
      <button id="addTaskBtn" class="btn btn-primary">Add Task</button>
      <button id="showAllBtn" class="btn btn-default" onclick="javascript:getalltask();">Show All Tasks</button>
    </div>

    <div class="col-12 response_msg" style="text-align:center; font: size 16px;"></div>
  </div>


<table class="table table-bordered" id="data-list">
    <thead>
      <tr>
        <th>Id</th>
        <th>Task Title</th>
        <th>Status</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody class="body-data"> 
      @if($tasks->count()>0)
     @foreach($tasks as $task)
      <tr>
        <td>{{$task->id}}</td>
        <td>{{$task->task_name}}</td>
        <td id="{{'task_status_'.$task->id}}">{{ ($task->task_status =='1' ? 'Completed' : 'Not Completed') }} </td>
        <td><input type="checkbox" name="task_status[]" data-id="{{$task->id}}" id="{{$task->id}}" class="completeTask"   @if($task->task_status =='1') {{'checked'}} @endif  >  || 
        
        <a href= "javascript:void()" onclick="return confirm('Are you sure to delete it');"  class="delete" id="{{$task->id}}">Delete</a>
    
    </td>
      </tr>
      @endforeach
    @endif
    </tbody>
  </table>
@endsection


@push('scripts')
<script>

let csrfToken = $('meta[name="csrf-token"]').attr('content');


$("#data-list").on('click', '.delete', function (e) {
    
    e.preventDefault();
    let row = $(this).closest('tr');
    let task_id = $(this).attr('id');
    let task = $('#task').val();
    $.ajax({
    url: '{{ route('delete_task') }}',  
    method: 'POST',
    data: {
    task_id: task_id,
    _token: csrfToken
    },
    success: function(response) {
      row.fadeOut(400, function() {
        row.remove(); // Remove after fade out
      });
        
    }
    });

});



$(document).on('change', '.completeTask', function (e) {
    
    //let checked_box = $(this).prop('checked', true);

    const isChecked = $(this).is(":checked");
    let   task_id = $(this).attr('id');
    let   status_id = 'task_status_'+task_id;
    let row = $(this).closest('tr');
    let   currentstatus = "Not Completed";

   
    
    e.preventDefault();
    let task = $('#task').val();
    $.ajax({
      url: '{{ route('update_task') }}',  
      method: 'POST',
      data: {task_id: task_id, _token: csrfToken },
      success: function(response) {
      if(isChecked)
      {
        row.fadeOut(400, function() {
          row.remove(); 
        });
      }
      else{
        $('#'+status_id).text(currentstatus);
      }
      }
     
    });
    
});


$('#addTaskBtn').on('click', function(e) {
        e.preventDefault();
        addTask();
    });

    // Handle "Enter" key press
    $('#task_name').on('keypress', function(e) {
        if (e.which === 13) { // 13 is the key code for "Enter"
            e.preventDefault();
            addTask();
        }
    });


  function addTask() {
    
    let row = $(this).closest('tr');
    let taskName = $('#task_name').val();
    $.ajax({
      url: '{{ route('save_task') }}',  
      method: 'POST',
      data: {task_name: taskName, _token: csrfToken },
      success: function(response) {
        console.log(response.success);
      if(response.success===false)
      {
        $('.response_msg').html(response.message.task_name[0]).css('color', 'red');;
        return false;
      }


       $('.response_msg').html(''); 
       $('.response_msg').html(response.message).css('color', 'green');
        console.log(response.task.id);
        $('#task_name').val('');
        let status = (response.task.task_status) ? 'Completed' : "Not Completed"; 
        let checkstatus = (response.task.task_status =='1') ? 'checked' : "";  
        let checkbox = '<input class="completeTask" name="task_status[]" data-id="'+response.task.id+'" id="'+response.task.id+'" type="checkbox" '+checkstatus+'>';

        let action = '<a href="javascript:void(0)" onclick="return confirm(\'Are you sure you want to delete it?\');" class="delete" id="' + response.task.id + '">Delete</a>';
        let dataadd = '<tr><td>'+response.task.id+'</td><td>'+response.task.task_name+'</td><td id="task_status_'+response.task.id+'">'+status+'</td><td>'+checkbox+' || '+action+'</td></tr>';

        $('#data-list').append(dataadd)



      }
    });

}



function getalltask()
{

  $.ajax({
      url: '{{ route('getlist') }}',  
      method: 'GET',
      data: { _token: csrfToken },
      success: function(data) {
        $('.body-data').html('');
        data.forEach(function(response, index) {
        let status = (response.task_status) ? 'Completed' : "Not Completed"; 
        let checkstatus = (response.task_status =='1') ? 'checked' : "";  
        let checkbox = '<input class="completeTask" name="task_status[]" data-id="'+response.id+'" id="'+response.id+'" type="checkbox" '+checkstatus+'>';

    let action = '<a href="javascript:void(0)" onclick="return confirm(\'Are you sure you want to delete it?\');" class="delete" id="' + response.id + '">Delete</a>';
        let dataadd = '<tr><td>'+response.id+'</td><td>'+response.task_name+'</td><td id="task_status_'+response.id+'">'+status+'</td><td>'+checkbox+' || '+action+'</td></tr>';
        $('#data-list').append(dataadd)
      });
      
      }
     
     
    });
}



</script>



@endpush


