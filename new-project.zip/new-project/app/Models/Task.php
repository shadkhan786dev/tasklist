<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    use HasFactory;

    protected $table = "taskmanagers";

    public function  getTaskList()
    {
        return $this->all();
    }


    public function  delete_task($task_id)
    {

        $this->where('id',$task_id)->delete();
        return true;
    }

    public function  update_task($task_id)
    {
        $task = $this->where('id',$task_id)->first();
        if($task->task_status=='1')
        $task->task_status = 0;
        else
        $task->task_status = 1;
        $task->save();
        return true;
    }

    public function save_task($request)
    {
       
       $task  = new self();
       $task->task_name = $request['task_name'];
       $task->task_assign_date =  now();
       $task->save();
       return $task->fresh();
      

    }

}
   
