<?php
namespace App\Interfaces;



interface TaskInterface
{
    
    public function  save_task($request);
    public function  getTaskList();
    public function  delete_task($task_id);
    public function  update_task($task_id);
}
