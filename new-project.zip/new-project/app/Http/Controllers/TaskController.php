<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Interfaces\TaskInterface;
use Illuminate\Support\Facades\Validator;

class TaskController extends Controller
{
      private  $taskInterface;

        public function __construct(TaskInterface $taskInterface)
        {
            $this->taskInterface = $taskInterface;
        }


        public function list(Request $request)
        {
            $tasks = $this->taskInterface->getTaskList();
           
            return view('task.task-list',compact('tasks'));
          
        }

        public function getlist(Request $request)
        {
            $tasks = $this->taskInterface->getTaskList();
           
            return $tasks;
          
        }


        

        public function save_task(Request $request)
        {

            $validator = Validator::make($request->all(), [
                'task_name' => 'required|string|unique:taskmanagers,task_name',
            ],
            [
                'task_name.required' => 'The task field is required. Please enter a task.',
                'task_name.unique'   => 'This task already exists. Please enter a different task.',
            ]
            );
            if($validator->fails()) {
               return  response()->json(['success' => false, 'message'=>$validator->errors()]);
            }
            
            $data =  $request->all();
            $task = $this->taskInterface->save_task($data);
            return response()->json([
                'success' => true,
                'message' => 'Record has been saved successfully!',
                'task' => $task
            ]);
            
        }



        public function delete_task(Request $request)
        {
         $this->taskInterface->delete_task($request->task_id);
         return true;
        } 

        public function update_task(Request $request)
        {
         $this->taskInterface->update_task($request->task_id);
         return true;
        } 


        

}
