<?php

namespace App\Repositories;
use App\Interfaces\TaskInterface;
use App\Models\Task;
use Illuminate\Support\Facades\Hash;


class TaskRepository implements TaskInterface
{
    private  $task;

    public function __construct()
    {
        $this->task = new Task();
    }

    public function save_task($request)
    {
        return $this->task->save_task($request);
    }

    public function  getTaskList()
    {
        return $this->task->getTaskList();
    }

    public function  delete_task($task_id)
    {
        return $this->task->delete_task($task_id);
        
    }

    public function  update_task($task_id)
    {
        return $this->task->update_task($task_id);
        
    }


}
   
   ?>